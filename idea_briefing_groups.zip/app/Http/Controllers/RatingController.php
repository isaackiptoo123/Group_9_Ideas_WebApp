<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Idea;
use App\Models\ratings;

class RatingController extends Controller
{
    public function index(){
        
    }
}
