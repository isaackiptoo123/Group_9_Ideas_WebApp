
<?php $__env->startSection('menu'); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<style>
    h6 span{
        font-weight: normal;
    }
</style>

<div id="main">
    <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
            <i class="bi bi-justify fs-3"></i>
        </a>
    </header>
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>My Profile</h3>
                <p class="text-subtitle text-muted">Update my profile</p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        

                          <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                          data-bs-target="#staticBackdrop">
                          <i class="bi bi-pencil-square"></i>  Edit
                      </button>

                      <!-- disabled animation Modal -->
                      <div class="modal text-left" id="staticBackdrop" tabindex="-1" role="dialog" data-bs-backdrop="static" data-bs-keyboard="false"
                          aria-labelledby="myModalLabel6" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"
                              role="document">
                              <div class="modal-content">
                                  <div class="modal-header">
                                      <h4 class="modal-title" id="myModalLabel6">Edit your details
                                      </h4>
                                      <button type="button" class="close" data-bs-dismiss="modal"
                                          aria-label="Close">
                                          <i data-feather="x"></i>
                                      </button>
                                  </div>
                                  <div class="modal-body">
                                     <div class="col-md-12">
                                        <form method="POST" action="<?php echo e(route('profile_user/store', $users->id)); ?>" class="md-float-material">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                        <div class="row">
                                            <div class="col-lg-12 mb-1">
                                                <div class="input-group mb-3">
                                                    <span class="input-group-text" id="basic-addon1">Name</span>
                                                    <input type="text" class="form-control" name="name" value="<?php echo e($users->name); ?>"
                                                        aria-label="Username" aria-describedby="basic-addon1">
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-1">
                                                <div class="input-group mb-3">
                                                    <span class="input-group-text" id="basic-addon1">Email</span>
                                                    <input type="text" class="form-control" name="email" value="<?php echo e($users->email); ?>"
                                                        aria-label="Username" aria-describedby="basic-addon1">
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-1">
                                                <div class="input-group mb-3">
                                                    <span class="input-group-text"  id="basic-addon1">Date Of Birth</span>
                                                    <input type="date" class="form-control" name="birth_date" required
                                                        aria-label="Username" aria-describedby="basic-addon1">
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-1">
                                                <div class="input-group mb-3">
                                                    <span class="input-group-text" id="basic-addon1">Phone Number</span>
                                                    <input type="number" class="form-control" name="phone" value="<?php echo e($users->phone_number); ?>"
                                                        aria-label="Username" aria-describedby="basic-addon1">
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-1">
                                            <div class="form-group position-relative has-icon-left mb-4">
                                                <fieldset class="form-group">
                                                    <select class="form-select <?php $__errorArgs = ['role_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ideas" id="investment">
                                                        <option selected value="<?php echo e($users->ideas); ?>"><?php echo e($users->ideas); ?></option>
                                                        <option value="Real Estate">Real Estate</option>
                                                        <option value="Equities">Equities</option>
                                                        <option value="Crypto">Crypto</option>
                                                    </select>
                                                    <div class="form-control-icon">
                                                        <i class="bi bi-exclude"></i>
                                                    </div>
                                                </fieldset>
                                                <?php $__errorArgs = ['role_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            
                                        </div>
                                     </div>
                                       
                                  </div>
                                  <div class="modal-footer">
                                      <button type="button" class="btn btn-light-secondary"
                                          data-bs-dismiss="modal">
                                          <i class="bx bx-x d-block d-sm-none"></i>
                                          <span class="d-none d-sm-block">Close</span>
                                      </button>
                                      <button type="submit" class="btn btn-primary ml-1">
                                          <i class="bx bx-check d-block d-sm-none"></i>
                                          <span class="d-none d-sm-block">Update</span>
                                      </button>
                                  </div>
                                </form>
                                    
                              </div>
                          </div>
                      </div>
                      
                        
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <!-- Modal -->

    
    <?php echo Toastr::message(); ?>


    <div id="auth">

        <div class="row h-100">            
            <div class="col-lg-6 col-6">
                     <div class="card bg-col">
                        <div class="row">
                            <div class="col-lg-3">
                                <div class="d-flex align-items-center mt-3">
                                    <div class="avatar avatar-xl pl-4">
                                <img src="<?php echo e(URL::to('/images/'. Auth::user()->avatar)); ?>" alt="<?php echo e(Auth::user()->avatar); ?>" class="rounded-circle">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-9">
                                <div class="card-body">
                                    <h6>Name: <span><?php echo e($users->name); ?> </span></h6>                                                       
                                    <h6>Email: <span><?php echo e($users->email); ?> </span></h6> 
                                    <h6>Role: <span><?php echo e($users->role_name); ?></span> </h6>                                                     
                                  
                                </div>
                            </div>
                        </div>
                        
                        
                      </div>
                  
            </div>
            <div class="col-lg-6 col-6">           
                                
                <div class="card bg-col">
                    <div class="card-body">
                        <h6>Phone Number: <span><?php echo e($users->phone_number); ?></span></h6>
                        <h6>Date of Birth: <span><?php echo e($users->birth_date); ?></h6>                        
                        <h6>Ideas: <span><?php echo e($users->ideas); ?></span> </h6>                          
                      
                    </div>
                  </div>
              
        </div>
            
        </div>
    </div>

    <footer>
        <div class="footer clearfix mb-0 text-muted">
            <div class="float-start">
                <p>2023 &copy; Group 9</p>
            </div>
            <div class="float-end">
                <p>Crafted with <span class="text-danger"><i class="bi bi-heart"></i></span> by <a
                href="#">Group 9</a></p>
            </div>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.user_activity_log', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\idea_briefing_groups\resources\views/usermanagement/profile_user.blade.php ENDPATH**/ ?>