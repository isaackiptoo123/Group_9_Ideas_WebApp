<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header">
            <div class="d-flex justify-content-between">
                
                <div class="toggler">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <li class="sidebar-title">Menu</li>
                <li class="sidebar-item active">
                    <a href="<?php echo e(route('home')); ?>" class='sidebar-link'>
                        <i class="bi bi-house-fill"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

             

              

                <?php if(Auth::user()->role_name=='Super Admin'): ?>
                <li class="sidebar-item">
                    <div class="card-body">
                        <div class="badges">
                            <?php if(Auth::user()->role_name=='Admin'): ?>
                            <span>Name: <span class="fw-bolder"><?php echo e(Auth::user()->name); ?></span></span>
                            <hr>
                            <span>Role Name:</span>
                            <span class="badge bg-success">Admin</span>
                            <?php endif; ?>   
                            <?php if(Auth::user()->role_name=='Super Admin'): ?>
                                <span>Name: <span class="fw-bolder"><?php echo e(Auth::user()->name); ?></span></span>
                                <hr>
                                <span>Role Name:</span>
                                <span class="badge bg-info">Super Admin</span>
                            <?php endif; ?>
                            <?php if(Auth::user()->role_name=='Normal User'): ?>
                                <span>Name: <span class="fw-bolder"><?php echo e(Auth::user()->name); ?></span></span>
                                <hr>
                                <span>Role Name:</span>
                                <span class="badge bg-warning">User Normal</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </li>
                    
                   
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('ideas')); ?>" class='sidebar-link'>
                            <i class="bi bi-hexagon-fill"></i>
                            <span>Briefing Ideas</span>
                        </a>
                      
                    </li>
                    
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('allusers')); ?>" class='sidebar-link'>
                            <i class="bi bi-people"></i>
                            <span>All Users</span>
                        </a>
                      
                    </li>
                    <?php else: ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('related')); ?>" class='sidebar-link'>
                            <i class="bi bi-file-earmark-medical-fill"></i>
                            <span>My Suggestions</span>
                        </a>
                      
                    </li>
                <?php endif; ?>

                <li class="sidebar-item">
                    <a href="/profile_user" class='sidebar-link'>
                        <i class="bi bi-person"></i>
                        <span>My Profile</span>
                    </a>
                </li>
                
                <li class="sidebar-item">
                    <a href="<?php echo e(route('change/password')); ?>" class='sidebar-link'>
                        <i class="bi bi-shield-lock"></i>
                        <span>Change Password</span>
                    </a>
                </li>
                
                
                <li class="sidebar-item">
                    <a href="<?php echo e(route('logout')); ?>" class='sidebar-link'>
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Log Out</span>
                    </a>
                </li>
            </ul>
        </div>
        <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>
</div><?php /**PATH C:\Users\user\Documents\idea_briefing_groups\resources\views/sidebar/user_activity_log.blade.php ENDPATH**/ ?>